@extends('layouts.app')

@section('content')
<h1>ediwaw</h1>
@endsection