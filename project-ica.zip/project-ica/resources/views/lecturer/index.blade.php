@extends('layouts.app')
@section('content')

<legend>Lecturer</legend>

@endsection