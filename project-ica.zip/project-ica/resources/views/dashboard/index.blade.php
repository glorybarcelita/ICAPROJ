@extends('layouts.app')
@section('content')
    <h2>Informatics Comprehensive Assessment</h2>
@endsection