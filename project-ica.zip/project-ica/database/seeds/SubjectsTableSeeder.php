<?php

use Illuminate\Database\Seeder;
use App\Models\Subjects;
class SubjectsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    //      Course::create([
            
    //         'course_id' => 1,
    //         'name' => 'JAVA',
    //         'description' => 'Sample Description for JAVA.',
    //         'year_level' => '1'
        
    //     ]);
        
      
        
    //   Course::create([
            
    //          'course_id' => 1,
    //         'name' => 'ENGLISH',
    //         'description' => 'Sample Description for ENGLISH.',
    //         'year_level' => '1'
        
    //     ]);
    }
}
