<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-default">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                       <div class="col-md-4">
                          <center>
                            <a href="<?php echo e(route('users.index')); ?>"><span class="sr-only">(current)</span><i class="fa fa-users fa-fontsize" aria-hidden="true"></i>icon</a>
                            
                            <h6>Users</h6>  
                            <h1>000</h1>
                          </center>
                        </div>

                        <div class="col-md-4">
                          <center>
                             <a href="<?php echo e(route('learningresources.index')); ?>"><span class="sr-only">(current)</span><i class="fa fa-star-o fa-fontsize" aria-hidden="true"></i>icon</a>
                            
                            <h6>Learning Resources</h6>
                            <h1>000</h1>
                          </center>
                        </div>

                        <div class="col-md-4">
                          <center>
                            <a href="<?php echo e(route('learningresources.index')); ?>"><span class="sr-only">(current)</span><i class="fa fa-star-o fa-fontsize" aria-hidden="true"></i>icon</a>
                            
                            <h6>Achiever's Wall</h6>
                            <h1>000</h1>
                          </center>
                        </div>
                    </div>
                </div>
            </div>
              <div class="card-body">
                     <table class="table table-bordered" id="myTable">
                    <thead>
                        <th>Actions</th>
                        <th>ID</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Date Created</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('users.edit',['id' => $user->id] )); ?>" class="btn btn-sm btn-success text-light">Edit</a>
                            </td>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->firstname); ?></td>
                            <td><?php echo e($user->lastname); ?></td>
                            <td><?php echo e($user->role->name); ?></td>
                            <td><?php echo e($user->is_active); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>