<?php $__env->startSection('content'); ?>

    <h3 class="text-info"><?php echo e($subject->name); ?> > Exams</h3>
    <a href="<?php echo e(url('exams/addquestion').'/'.$subject->id); ?>" class="btn btn-md btn-info mt-3 pull-right">Add Question</a>
    <div class="container mt-4">
      <div class="card card-info">
        <div class="card-header">
            Exam questions
        </div>
        <div class="card-body">
            <table class="table table-bordered mt-4" id="myTable">
              <thead>
                <tr>
                  <th width="100px">Action</th>
                  <th>Question</th>
                  <th>Choice 1</th>
                  <th>Choice 2</th>
                  <th>Choice 3</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <a href="<?php echo e(url('exams/updatequestion/'.$subject->id.'/'.$question->id)); ?>" class="btn btn-sm btn-outline-info">Edit</a>&nbsp;&nbsp;&nbsp;
                    <a href="<?php echo e(url('exams/deletequestion/'.$subject->id.'/'.$question->id)); ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                  </td>
                  <td><?php echo e($question->question); ?></td>
                  <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($choice->exam_id == $question->id): ?>
                      <td <?php echo e($choice->is_correct == 'true' ? 'style=background-color:#28a745!important;':''); ?>>
                        <?php echo e($choice->choices); ?>

                      </td>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>