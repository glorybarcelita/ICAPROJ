<?php $__env->startSection('content'); ?>
 
  <div class="container mt-4">
     <h3 class="text-info">PLF</h3>
     
     <muted class="text-secondary">Is a subject that has a collection of topics with learning Resources</muted>
    <br>
    
    
    <a href="<?php echo e(route('subjecttopic.create',['id' => $subjects->id])); ?>" class="btn btn-md btn-info mt-3">Add Topic</a>
    <div class="card card-info  mt-3">
    
         <div class="row">
               
                <div class="col-sm-3">
                    <div class="card border-info my-3 mx-3" style="max-width: 20rem;">
                      <div class="card-header">
                        <h5><a href="<?php echo e(route('subjecttopic.show')); ?>" class="label text-info">aaaa</a></h5>
                      </div>
                      
                      <div class="card-body">
                          
                          <h6 class="text-info">Description</h6>
                          <p class="card-text">sampleee</p>
                          <h6 class="text-info">Lecturer</h6>
                          <p class="card-text">ediaww</p>
                      </div>
                      <div class="card-footer">
                          <button class="btn btn-info" data-toggle="modal" data-target="#updateIcaSubject">Update</button>
                      </div>
                    </div>
                </div>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>