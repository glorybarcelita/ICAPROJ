<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <legend>Subjects</legend>
      
    <div class="card card-info mt-3">
        <div class="card-header">
            Subjects Table
            <?php if(Auth::user()->role_id == '1'): ?>
                
                 <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-info btn-sm float-right">Create Subject</a>
            <?php endif; ?>

        </div>
        <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Actions</th>
                    <th>Subject Name</th>
                    <th>Course</th>
                    <th>Subject Description</th>
                    <th>Year Level</th>
                    
                </thead>
                <tbody>
                   <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if(Auth::user()->role_id == '1'): ?>
                                <button class="btn btn-sm btn-outline-danger " onclick="subjects_delete(this.name);" name="<?php echo e($subject->id); ?>">Delete</button>

                               
                                <a href="<?php echo e(route('subjects.edit',['id' => $subject->id] )); ?>" class="btn btn-sm btn-outline-info">Edit</a>
                                <a href="<?php echo e(route('subjects.show',['id' => $subject->id] )); ?>" class="btn btn-sm btn-outline-primary">Syllabus</a>
                                
                            <?php elseif(Auth::user()->role_id == '2'): ?>
                                <a href="<?php echo e(url('sujects/assign-lecturer').'/'.$subject->id); ?>" class="btn btn-info btn-sm float-right">Assign a Lecturer</a>
                            <?php endif; ?>

                        </td>
                        
                        <td><?php echo e($subject->name); ?></td>
                        
                        <td>
                            <?php $__currentLoopData = $subj_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subj_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($subject->id == $subj_course->subject_id ? $subj_course->course_id == $course->id ? $course->name:'' :''); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        
                        <td><?php echo e($subject->description); ?></td>
                        <td><?php echo e($subject->year_level); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           A Total Registered Subject of <?php echo e($subjects->count()); ?>

        </div>
        </div>
    </div>
</div>

<!--MODAL FOR DELETE--> 
<div class="modal fade" id="mod-syllabus-delete" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">     <?php echo e(csrf_field()); ?>

        <div class="modal-header">
          <h5 class="modal-title">Delete Subject?</h5>
        </div>
        <div class="modal-body">
          <label>Are you sure you want to delete this Subject?</label>
          <input type="hidden" id="syl_id" name="subject_id_delete">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="btn-delete-topic-no">No</button>
          <button type="submit" class="btn btn-primary" id="btn-delete">Yes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
    function syllabus_delete($id) {
        var syllabus_id = $id;
        $('#syl_id').val(syllabus_id);
        $('#mod-syllabus-delete').modal('show');
    };
</script>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>