<?php $__env->startSection('content'); ?>
    
    <br>
   
      <div class="col-lg-12">
         <h3 class="text-info"><?php echo e($subject->name); ?></h3>
         <h6>Year Level: <?php echo e($subject->year_level); ?></h6>
     <muted class="text-secondary"><strong>Description: </strong><?php echo e($subject->description); ?></muted>
     <hr>
     
      <?php if(Auth::user()->role_id == 3): ?>
        <a href="<?php echo e(url('learning-resources/subject/create').'/'.$subject_id); ?>" class="btn btn-md btn-info mt-3 pull-right">Add Topic</a>
        <a href="<?php echo e(url('exams/'.$subject_id)); ?>" class="btn btn-md btn-info mt-3 pull-right">View Exam</a>
      <?php elseif(Auth::user()->role_id == 4): ?>
         <?php if(count(App\Exam::where('subject_id', $subject->id)->get())>0): ?>
            <a href="<?php echo e(url('exams/'.$subject_id)); ?>" class="btn btn-md btn-info mt-3 pull-right btnExam">Take Exam</a>
          <?php endif; ?>
      <?php elseif(Auth::user()->role_id == 1 || Auth::user()->role_id == 2): ?>
        <?php if(count(App\Exam::where('subject_id', $subject->id)->get())>0): ?>
        <a href="<?php echo e(url('exams/'.$subject_id)); ?>" class="btn btn-md btn-info mt-3 pull-right">View Exam</a>
         <?php endif; ?>
      <?php endif; ?>
   
    </div>
    <div class="card card-info  my-3 ml-3">
        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
            <?php if(Auth::user()->role_id==4): ?>
              <h4 class="text-dark col-lg-12 mx-3 mt-2"><?php echo e($topic->name); ?>

                  <br>
                  <?php if(count(App\Quiz::where('syllabus_id', $topic->id)->get())>0): ?>
                  <a href="<?php echo e(url('quiz/'.$subject->id.'/'.$topic->id)); ?>" class="btn btn-sm btn-secondary mt-2 pull-right btn<?php echo e($topic->id); ?>">Take quiz</a>
                  <div class="div<?php echo e($topic->id); ?>"></div>
                  <?php endif; ?>
              </h4>
            <?php elseif(Auth::user()->role_id==3): ?>
              <h4 class="text-dark col-lg-12 mx-3 mt-2"><?php echo e($topic->name); ?> <br> 
                
                <a href="<?php echo e(url('quiz/'.$subject->id.'/'.$topic->id)); ?>" class="btn btn-sm btn-secondary mt-2 pull-right">View quiz</a>
                
              </h4>
            <?php else: ?>
              <h4 class="text-dark col-lg-12 mx-3 mt-2"><?php echo e($topic->name); ?> <br> 
                <?php if(count(App\Quiz::where('syllabus_id', $topic->id)->get())>0): ?>
                <a href="<?php echo e(url('quiz/'.$subject->id.'/'.$topic->id)); ?>" class="btn btn-sm btn-secondary mt-2 pull-right">View quiz</a>
                <?php endif; ?>
              </h4>
            <?php endif; ?>
            <?php if(count($subject_topics) > 0): ?>
              <?php $__currentLoopData = $subject_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($subject_topic->syllabus_id == $topic->id): ?>
                <div class="col-sm-3">
                  <div class="card border-info my-3 mx-3" style="max-width: 25rem;">
                    <div class="card-header">
                      <h5><a href="<?php echo e(url('learning-resources/subject/details').'/'.$subject_id.'/'.$topic->id.'/'.$subject_topic->id); ?>" class="label text-info"><?php echo e($subject_topic->topic_title); ?></a></h5>
                    </div>
                    
                    <div class="card-body">
                        <h6 class="text-info">Note</h6>
                        <p class="card-text"><?php echo e(str_limit($subject_topic->note, 10)); ?> </p>
                    </div>
                    <?php if(Auth::user()->role_id == 3): ?>
                      <div class="card-footer">
                          <button class="btn btn-sm btn-outline-success" data-toggle="modal" data-target="#updateIcaSubject">Update</button>
                          <button class="btn btn-sm btn-outline-danger" data-toggle="modal" data-target="#updateIcaSubject">Delete</button>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <p class="col-lg-12" style="padding-left: 50px;">No Topics Added.</p>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script type="text/javascript">
    $( document ).ready(function() {
      var fail_count = 0;
      <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($quiz_record)>0): ?>
          <?php $__currentLoopData = $quiz_record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($record->quiz_id == $topic->id): ?>
              <?php if($record->pass_fail == 'pass'): ?>
                $('.btn<?php echo e($record->quiz_id); ?>').hide();
              <?php else: ?>
                fail_count = fail_count + 1;
              <?php endif; ?>
              $('.div<?php echo e($record->quiz_id); ?>').show();
              $('.div<?php echo e($record->quiz_id); ?>').html(' Quiz result: <?php echo e(strtoupper($record->pass_fail)); ?> ');
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                if(fail_count >= 1){
            $('.btnExam').hide();
          }
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>