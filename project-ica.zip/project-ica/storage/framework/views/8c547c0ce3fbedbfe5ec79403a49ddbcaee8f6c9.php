<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card card-info">
        <div class="card-header">
            Add User
        </div>
        <div class="card-body">
            <?php echo $__env->make('shared.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form method="POST" action="<?php echo e(route('users.update',['id'=> $user->id ] )); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

            <div class="form-group row">
                <label for="is_active" class="col-sm-2 col-form-label">Status</label>
                <div class="col-sm-10">
                     <select id="is_active" name="is_active" class="form-control">
                        <option value="0" <?php if(!$user->is_active): ?> selected <?php endif; ?>>Inactive</option>
                        <option value="1" <?php if($user->is_active): ?> selected <?php endif; ?>>Active</option>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="role_id" class="col-sm-2 col-form-label">Role</label>
                <div class="col-sm-10">
                     <select id="role_id" name="role_id" class="form-control">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" <?php if($user->role_id == $role->id ): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
              <label for="stud_course" class="col-sm-2 col-form-label">Course</label>
              <div class="col-sm-10">
                  <select id="stud_course" name="stud_course" class="form-control">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>" <?php if($user->course == $course->id ): ?> selected <?php endif; ?>><?php echo e($course->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
              </div>
          </div>
            <div class="form-group row">
            <label for="user-status" class="col-sm-2 col-form-label">Full Name</label>
                <div class="col">
                     <input type="text" class="form-control" id="" name="firstname" value="<?php echo e(old('firstname') ?: $user->firstname); ?>" placeholder="First name">
                </div>
                <div class="col">
                     <input type="text" class="form-control" id="" name="middlename"value="<?php echo e(old('middlename') ?: $user->middlename); ?>"  placeholder="Middle Initial name">
                </div>
                <div class="col">
                     <input type="text" class="form-control" id="" name="lastname" value="<?php echo e(old('lastname') ?: $user->lastname); ?>" placeholder="Last name">
                </div>
          </div>
          
          <div class="form-group row">
              <label for="user-status" class="col-sm-2 col-form-label">Email</label>
              <div class="col-sm-10">
                  <input type="email" class="form-control" id="" name="email" value="<?php echo e(old('email') ?: $user->email); ?>" placeholder="Enter email">
              </div>
          </div>

          <center><button type="submit" class="btn btn-primary">Save</button></center>
        </div>
        </form>
        <div class="card-footer">
            Register User
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let course = $('#stud_course');
        course.attr('disabled','disabled')
        $('#role_id').change(function()
        {
            let role = $('#role_id').val()
            if(role == 4)
            {
               course.removeAttr('disabled')
            }
            else
            {
              course.attr('disabled','disabled')
            }
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>