<?php $__env->startSection('content'); ?>
    <h3 class="text-info"><?php echo e($subject->name); ?> > <?php echo e($syllabus->name); ?> > Quiz</h3>
    <a href="<?php echo e(url('quiz/add-question/'.$syllabus->id)); ?>" class="btn btn-md btn-info mt-3 pull-right">Add Question</a>
    <div class="container mt-4">
      <div class="card card-info">
        <div class="card-header">
            Quiz questions
        </div>
        <div class="card-body">
          
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>