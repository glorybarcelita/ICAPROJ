<?php $__env->startSection('content'); ?>

<div class="container mt-4">
     <h3 class="text-info"><?php echo e($subject->name); ?> > <?php echo e($syllabus->name); ?> > <?php echo e($topic->topic_title); ?></h3>
    <br>
    <table class="table">
      <tr>
        <td style="width: 150px;">Notes:
        </td>
        <td>
            <?php echo e($topic->note); ?>

        </td>
      </tr>
      <tr>
        <td style="width: 150px;">Links:
        </td>
        
        
         
        <td>
        </td>
      </tr>
      <tr>
        <td style="width: 150px;">Attachments:
        </td>
        <td>
          <?php if($file_count>0): ?>
            <?php $__currentLoopData = $file_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p><a href="<?php echo e(url('storage/'.$file)); ?>"><?php echo e(str_replace('subjects/topic/'.$topic->id.'/','',$file)); ?></a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <p>No file attached.</p>
          <?php endif; ?>
        </td>
      </tr>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>