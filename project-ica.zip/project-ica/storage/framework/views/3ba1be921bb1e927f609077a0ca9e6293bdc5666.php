<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <legend>Courses</legend>
    <div class="card card-info mt-4">
        <div class="card-header">
            Courses table
             <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-info btn-sm float-right">Create Course</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Actions</th>
                    <th>Status</th>
                    <th>Course Name</th>
                    <th>Description</th>
                    
                </thead>
                <tbody>
                   <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('courses.edit',['id' => $course->id ] )); ?>" class="btn btn-sm btn-outline-info">Edit</a>
                           <button type="button" id="<?php echo e($course->id); ?>" class="btn btn-sm btn-outline-danger btnDelete">Delete</button>
                        </td>
                        <td><?php echo e($course->is_active); ?></td>
                        <td><?php echo e($course->name); ?></td>
                        <td><?php echo e($course->description); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           A Total Registered Course of <?php echo e($courses->count()); ?>

        </div>
        </div>
    </div>
</div>

<!--MODAL FOR DELETE--> 
<div class="modal fade" id="mod-course-delete" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form method="POST" action="<?php echo e(url('course/delete')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="modal-header">
          <h5 class="modal-title">Delete course?</h5>
        </div>
        <div class="modal-body">
          <label>Are you sure you want to delete this course?</label>
          <input type="hidden" id="course_id" name="course_id_delete">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="btn-delete-topic-no" data-dismiss="modal">No</button>
          <button type="submit" class="btn btn-primary" id="btn-delete">Yes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<script type="text/javascript">
    $('.btnDelete').click(function(){
        $('#course_id').val(this.id);
        $('#mod-course-delete').modal('show');
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>