<?php $__env->startSection('content'); ?>
    
    <br>
   
      <div class="col-lg-12">
         <h3 class="text-info"><?php echo e($subject->name); ?></h3>
         <h6>Year Level: <?php echo e($subject->year_level); ?></h6>
     <muted class="text-secondary"><strong>Description: </strong><?php echo e($subject->description); ?></muted>
     <hr>
      <?php if(Auth::user()->role_id == 3): ?>
        <a href="<?php echo e(url('learning-resources/subject/create').'/'.$subject_id); ?>" class="btn btn-md btn-info mt-3 pull-right">Add Topic</a>
        <a href="<?php echo e(url('exams/'.$subject_id)); ?>" class="btn btn-md btn-info mt-3 pull-right">View Exam</a>
      </div>
    <?php endif; ?>
    <div class="card card-info  my-3 ml-3">
        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
            <h4 class="text-dark col-lg-12 mx-3 mt-2"><?php echo e($topic->name); ?> <br> <a href="<?php echo e(url('quiz/'.$subject->id.'/'.$topic->id)); ?>" class="btn btn-sm btn-secondary mt-2 pull-right">View quiz</a></h4>

            <?php if(count($subject_topics) > 0): ?>
              <?php $__currentLoopData = $subject_topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($subject_topic->syllabus_id == $topic->id): ?>
                <div class="col-sm-3">
                  <div class="card border-info my-3 mx-3" style="max-width: 25rem;">
                    <div class="card-header">
                      <h5><a href="<?php echo e(url('learning-resources/subject/details').'/'.$subject_id.'/'.$topic->id.'/'.$subject_topic->id); ?>" class="label text-info"><?php echo e($subject_topic->topic_title); ?></a></h5>
                    </div>
                    
                    <div class="card-body">
                        
                        <h6 class="text-info">Note</h6>
                        <p class="card-text"><?php echo e($subject_topic->note); ?></p>
                    </div>
                    <?php if(Auth::user()->role_id == 3): ?>
                      <div class="card-footer">
                          <button class="btn btn-sm btn-outline-success" data-toggle="modal" data-target="#updateIcaSubject">Update</button>
                          <button class="btn btn-sm btn-outline-danger" data-toggle="modal" data-target="#updateIcaSubject">Delete</button>
                      </div>
                    <?php endif; ?>
                  </div>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <p class="col-lg-12" style="padding-left: 50px;">No Topics Added.</p>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>