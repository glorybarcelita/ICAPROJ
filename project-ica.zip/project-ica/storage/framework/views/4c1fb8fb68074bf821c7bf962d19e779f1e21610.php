<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <legend>Quiz</legend>
    
    </div>
        <div class="card card-info mt-4">
        <div class="card-header">
            Quiz Question Statistics
             
        </div>
      <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Action</th>
                    <th>Subject > Topic > Question </th>
                    <th>No. of answered correct</th>
                    <th>No. of answered wrong</th>
                    
                </thead>
                <tbody>
                   <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                                <a href="<?php echo e(url('reports/quiz/stats/'.$quiz->id)); ?>" class="btn btn-outline-info">View Statistics</a>
                        </td>
                        <td>
                            <?php $__currentLoopData = $syllabuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syllabus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($syllabus->id == $quiz->syllabus_id ): ?>
                                        <?php echo e(App\Models\Subjects::find($syllabus->subject_id)->name); ?> > <?php echo e($syllabus->name); ?> > <?php echo e($quiz->question); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($quiz->correct_count); ?></td>
                        <td><?php echo e($quiz->wrong_count); ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           A Total Registered Course of 
        </div>
      </div>
    </div>


    <h5>Count</h5>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.0/css/buttons.dataTables.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.0/js/dataTables.buttons.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.5.0/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'print'
        ]
    });
</script>
<script type="text/javascript">
    $('.btnDelete').click(function(){
        $('#sub_id').val(this.id);
        $('#mod-subject-delete').modal('show');
    })
        
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>