<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h3 class="text-info"><?php echo e($subject->name); ?> > <?php echo e($syllabus->name); ?> > Quiz</h3>
        <a href="<?php echo e(url('quiz/add-question')); ?>/<?php echo e($subject->id); ?>/<?php echo e($syllabus->id); ?>" class="btn btn-md btn-info mt-3 pull-right">Add Question</a>
        <div class="card card-info mt-4">
            <div class="card-header">
            Quiz questions<br>

            </div>
            <div class="card-body">
              <table class="table table-bordered mt-4" id="myTable">
                  <thead>
                    <tr>
                      <th width="100px">Action</th>
                      <th>Question</th>
                      <th>Choice 1</th>
                      <th>Choice 2</th>
                      <th>Choice 3</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <a href="<?php echo e(url('quiz/update-question/'.$subject->id.'/'.$syllabus->id.'/'.$question->id)); ?>" class="btn btn-sm btn-outline-info">Edit</a>&nbsp;&nbsp;&nbsp;
                        <button type="button" id="<?php echo e($question->id); ?>" class="btn btn-sm btn-outline-danger btnDelete">Delete</a>
                      </td>
                      <td><?php echo e($question->question); ?></td>
                      <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($choice->quiz_id == $question->id): ?>
                          <td <?php echo e($choice->is_correct == 'true' ? 'style=background-color:#28a745!important;':''); ?>>
                            <?php echo e($choice->choices); ?>

                          </td>
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
        </div>
    </div>

<!--MODAL FOR DELETE--> 
<div class="modal fade" id="mod-quiz-delete" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="delete-record-topic" method="POST" action="<?php echo e(url('quiz/delete')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="modal-header">
          <h5 class="modal-title">Delete quiz?</h5>
        </div>
        <div class="modal-body">
          <label>Are you sure you want to delete this quiz question?</label>
          <input type="hidden" id="delQuiz" name="quiz_id_delete">
        </div>
        <div class="modal-footer">
          <button type="reset" class="btn btn-secondary" id="btn-delete-topic-no" data-dismiss="modal">No</button>
          <button type="submit" class="btn btn-primary" id="btn-delete">Yes</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();

    $('.btnDelete').click(function(){
      $('#delQuiz').val(this.id);
      $('#mod-quiz-delete').modal('show');
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>