<?php $__env->startSection('content'); ?>
 <div class="container mt-4">
     <legend>Learning Resources</legend>
     <muted>Is a subject that has a collection of topics with learning Resources</muted>    
    <div class="card card-info mt-3">
        <div class="card-header">
            Subject Collection
            <?php if(Auth::user()->role_id == 2): ?>
              <a href="" class="btn btn-sm btn-info float-right">Edit Approval</a>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php if(count($subjects) == 0): ?>
              <p>No topics added.</p>
            <?php else: ?>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(! ($subject->user_id == '' )): ?>
                    <div class="col-sm-3">
                        <div class="card border-info my-3 mx-3" style="max-width: 20rem;">
                          <div class="card-header"><h5><a href="<?php echo e(url('learning-resources/subject').'/'.$subject->id); ?>" class="label text-info"><?php echo e($subject->name); ?></a></h5></div>
                          
                          <div class="card-body">
                              <h6 class="text-info">Description</h6>
                              <p class="card-text"><?php echo e($subject->description); ?></p>
                              <h6 class="text-info">Lecturer</h6>
                              <?php $__currentLoopData = $lecturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($lecturer->id == $subject->user_id): ?>
                                  <p class="card-text"><?php echo e($lecturer->firstname); ?> <?php echo e($lecturer->middlename); ?> <?php echo e($lecturer->lastname); ?></p>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <h6 class="text-info">Status</h6>
                              <p class="card-text"><?php echo e($subject->is_active == 0 ? 'Inactive':'Active'); ?></p>
                          </div>
                        </div>
                    </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts..app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>