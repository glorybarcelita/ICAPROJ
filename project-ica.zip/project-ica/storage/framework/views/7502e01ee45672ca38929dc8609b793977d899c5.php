<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <legend>Users</legend>
    
  
    <div class="card card-info mt-3">
        <div class="card-header">
            Users Table
            <a href="<?php echo e(url('users/request')); ?>" class="btn btn-sm btn-info float-right">Pending Requests</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Actions</th>
                    <th>ID</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Date Created</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('users.edit',['id' => $user->id] )); ?>" class="btn btn-sm btn-success text-light">Edit</a>
                        </td>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->firstname); ?></td>
                        <td><?php echo e($user->lastname); ?></td>
                        <td><?php echo e($user->role->name); ?></td>
                        <td><?php echo e($user->is_active); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           A Total Registered User of <?php echo e($users->count()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>