<?php $__env->startSection('content'); ?>

<a href="<?php echo e(URL::previous()); ?>" class="col-sm-3 btn btn-md btn-outline-secondary float-right mr-3">Go Back</a>
<br>
<div class="container mt-4">
    <div class="card card-info">
        <div class="card-header">
            Edit Subject
        </div>
         <div class="card-body">


            <form method="POST" action="<?php echo e(route('subjects.update',['id'=> $subjects->id])); ?>">
                <?php echo e(csrf_field()); ?>

                <?php echo $__env->make('shared.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo e(method_field('PUT')); ?>

                <div class="form-group row">
                <label for="is_active" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                         <select id="is_active" name="is_active" class="form-control">
                            <option value="0" <?php if(!$subjects->is_active): ?> selected <?php endif; ?>>Inactive</option>
                            <option value="1" <?php if($subjects->is_active): ?> selected <?php endif; ?>>Active</option>
                        </select>
                    </div>
                </div>
                
                
                
                <div class="form-group row">
                      <label for="user-status" class="col-sm-2 col-form-label">Course</label>
                    <div class="col-sm-4">
                        <select id="dates-field2" name="course_id[]" class="multiselect-ui form-control" multiple="multiple">
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     {{ $subjects->id == $subj_course->subject_id ? $subj_course->course_id == $course->id ? 'selected':'' :'' }}
                                    <option value="<?php echo e($course->id); ?>" <?php if(old('course_id[]') ): ?> selected <?php endif; ?>><?php echo e($course->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                                
                
                
                 <div class="form-group row">
                    <label for="user-status" class="col-sm-2 col-form-label">Subject Name</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="" name="subjectname" value = "<?php echo e(old('subjectname') ?: $subjects->name); ?>"  placeholder="Subject Name">
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="user-status" class="col-sm-2 col-form-label">Subject Description</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" name="description" placeholder="Description"><?php echo e(old('description') ?: $subjects->description); ?></textarea>             
                    </div>
               </div>
                
                <div class="form-group row">
                    <label for="user-status" class="col-sm-2 col-form-label">Year Level</label>
                    <div class="col-sm-10">
                      <select id="courseid" name="yearlevel" class="form-control">
                          <option>1</option>
                          <option>2</option>
                          <option>3</option>
                      </select>
                    </div>
                </div>
              <center><button type="submit" class="btn btn-primary">Save</button></center>
            </form>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/multiselect.js')); ?>">                                                                             </script>
<script type="text/javascript">
$(function() {
    $('.multiselect-ui').multiselect({
        includeSelectAllOption: true
    });
});

$(function(){
  //Do it simple
  // var data="1,2,3,4";
  var data="";

  <?php $__currentLoopData = App\Models\SubjectCourse::where('subject_id', $subjects->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      data += "<?php echo e($course_id->course_id); ?>,";
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  //Make an array
  var dataarray=data.split(",");
  // Set the value
  $(".multiselect-ui").val(dataarray);
  // Then refresh
  $(".multiselect-ui").multiselect("refresh");
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<style>
    span.multiselect-native-select {
	position: relative
}
span.multiselect-native-select select {
	border: 0!important;
	clip: rect(0 0 0 0)!important;
	height: 1px!important;
	margin: -1px -1px -1px -3px!important;
	overflow: hidden!important;
	padding: 0!important;
	position: absolute!important;
	width: 1px!important;
	left: 50%;
	top: 30px
}
.multiselect-container {
	position: absolute;
	list-style-type: none;
	margin: 0;
	padding: 0
}
.multiselect-container .input-group {
	margin: 5px
}
.multiselect-container>li {
	padding: 0
}
.multiselect-container>li>a.multiselect-all label {
	font-weight: 700
}
.multiselect-container>li.multiselect-group label {
	margin: 0;
	padding: 3px 20px 3px 20px;
	height: 100%;
	font-weight: 700
}
.multiselect-container>li.multiselect-group-clickable label {
	cursor: pointer
}
.multiselect-container>li>a {
	padding: 0
}
.multiselect-container>li>a>label {
	margin: 0;
	height: 100%;
	cursor: pointer;
	font-weight: 400;
	padding: 3px 0 3px 30px
}
.multiselect-container>li>a>label.radio, .multiselect-container>li>a>label.checkbox {
	margin: 0
}
.multiselect-container>li>a>label>input[type=checkbox] {
	margin-bottom: 5px
}
.btn-group>.btn-group:nth-child(2)>.multiselect.btn {
	border-top-left-radius: 4px;
	border-bottom-left-radius: 4px
}
.form-inline .multiselect-container label.checkbox, .form-inline .multiselect-container label.radio {
	padding: 3px 20px 3px 40px
}
.form-inline .multiselect-container li a label.checkbox input[type=checkbox], .form-inline .multiselect-container li a label.radio input[type=radio] {
	margin-left: -20px;
	margin-right: 0
}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>