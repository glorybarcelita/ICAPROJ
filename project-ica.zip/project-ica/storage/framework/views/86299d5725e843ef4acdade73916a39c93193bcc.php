<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <legend>Courses</legend>
    <div class="card card-info mt-4">
        <div class="card-header">
            Courses table
             <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-info btn-sm float-right">Create Course</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Actions</th>
                    <th>ID</th>
                    <th>Status</th>
                    <th>Course Name</th>
                    <th>Description</th>
                    
                </thead>
                <tbody>
                   <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('courses.edit',['id' => $course->id ] )); ?>" class="btn btn-sm btn-info text-light">Edit</a>
                           
                        </td>
                        <td><?php echo e($course->id); ?></td>
                        <td><?php echo e($course->is_active); ?></td>
                        <td><?php echo e($course->name); ?></td>
                        <td><?php echo e($course->description); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           A Total Registered Course of <?php echo e($courses->count()); ?>

        </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#myTable').DataTable();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>