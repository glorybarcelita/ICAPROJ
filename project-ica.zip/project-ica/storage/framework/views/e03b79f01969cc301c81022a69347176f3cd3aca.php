<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
    <div class="card card-info">
        <div class="card-header">
            Syllabus
            <a href="<?php echo e(route('syllabus.create')); ?>" class="btn btn-info btn-sm float-right">Create Subject</a>
        </div>
        
        
<!--TABLE FOR Syllabus-->
<div class="container mt-4">
    <div class="card card-info">
        <div class="card-header">
            <h3><?php echo e($subjects->name); ?></h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered" id="myTable">
                <thead>
                    <th>Actions</th>
                    <th>Syllabus</th>
                    <th>Description</th>
                   
                    
                </thead>
                <tbody>
                  
                </tbody>
            </table>
        </div>
        <div class="card-footer">
           
        </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>