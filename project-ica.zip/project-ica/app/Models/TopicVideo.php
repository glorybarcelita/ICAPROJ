<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopicVideo extends Model
{
    protected $table = 'topic_videos';
}
